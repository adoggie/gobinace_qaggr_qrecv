package binance_connector

const Name = "binance-connector-go"

const Version = "0.5.2"
