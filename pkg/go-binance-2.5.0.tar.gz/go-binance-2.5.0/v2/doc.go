// Package binance is a Golang SDK for binance APIs.
package binance
